/**
 * This is MyParseInt class used for white-box testing
 * @author Jiawei Liu
 *
 */
public class MyParseInt {
	
	/**
	 * This is myParseInt method, which converts string to integer as same as Integer.parseInt()
	 * 
	 * The function first checks if input is null or not, and exception is thrown if str is null.
	 * Then it discards as many whitespace characters as necessary until the first non-whitespace character is found. 
	 * Then, starting from this character, takes an optional initial plus or minus sign followed by as many numerical digits as possible, and interprets them as a numerical value.
	 * 
	 * If the input is empty or it contains only whitespace characters, exception is thrown
	 * If the input contains any non-numeric characters, exception is throw
	 * If the correct value is out of the range of representable integer values, INT_MAX (2147483647) or INT_MIN (-2147483648) is returned.
	 * 
	 * Input examples: " 123", " +2018  ", " -201" 
	 * 
	 * @param str
	 * @return integer
	 */
	public int myParseInt(String str) {
        if (str == null) {
        	throw new IllegalArgumentException("Input string is null");
        }
        
        str = str.trim();
        
        if (str.length() == 0) {
        	throw new IllegalArgumentException("Input string is empty or it only contains spaces");
        }
        
        int index = 0;
        boolean isPositive = true;
        
        // check if first character of string is a optional sign
        if (str.charAt(0) == '+' || str.charAt(0) == '-') {
            index++;
            isPositive = str.charAt(0) == '+' ? true : false;
        }
        
        // variable used to store current integer value
        int res = 0;
        
        for (int i = index; i < str.length(); i++) {
            char c = str.charAt(i);
            
            if (!Character.isDigit(c)) {
            	throw new IllegalArgumentException("Input string contains non-numeric characters");
            }
            
            int num = c - '0';
            
            // check if integer is out of range
            if (res > Integer.MAX_VALUE / 10 || res == Integer.MAX_VALUE / 10 && num > Integer.MAX_VALUE % 10) {
            	return isPositive ? Integer.MAX_VALUE : Integer.MIN_VALUE;
            }
            
            res = res * 10 + num;
        }
        
        return isPositive ? res : -res;
    }
}
